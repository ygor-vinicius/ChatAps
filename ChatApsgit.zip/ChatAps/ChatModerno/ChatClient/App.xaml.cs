﻿using System;
using System.Windows;

namespace ChatClient
{
    public partial class App : Application
    {
        // Este arquivo é necessário para que o App.xaml funcione corretamente
    }
}
