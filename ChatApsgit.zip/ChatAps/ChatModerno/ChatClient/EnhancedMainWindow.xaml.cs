﻿// EnhancedMainWindow.xaml.cs
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

namespace ChatClient
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private NetworkStream stream;
        private Task receiveTask;
        private bool isConnected = false;
        private ObservableCollection<MessageItem> messages = new ObservableCollection<MessageItem>();
        private ObservableCollection<UserItem> users = new ObservableCollection<UserItem>();
        private Dictionary<string, Color> userColors = new Dictionary<string, Color>();
        private Random random = new Random();
        private bool isTransferring = false;
        private string currentTransferId = string.Empty;
        private Dictionary<string, FileTransferInfo> activeTransfers = new Dictionary<string, FileTransferInfo>();

        // Cores para avatares
        private Color[] avatarColors = new Color[]
        {
            Color.FromRgb(138, 43, 226),  // Roxo
            Color.FromRgb(64, 224, 208),   // Turquesa
            Color.FromRgb(255, 69, 0),     // Laranja
            Color.FromRgb(50, 205, 50),    // Verde
            Color.FromRgb(255, 215, 0),    // Amarelo
            Color.FromRgb(70, 130, 180),   // Azul
            Color.FromRgb(255, 105, 180),  // Rosa
            Color.FromRgb(106, 90, 205)    // Lavanda
        };

        // Constantes para o protocolo de mensagens
        private const string TEXT_MESSAGE = "TEXT";
        private const string EMOTICON_MESSAGE = "EMOTICON";
        private const string IMAGE_MESSAGE = "IMAGE";
        private const string FILE_INIT_MESSAGE = "FILE_INIT";
        private const string FILE_DATA_MESSAGE = "FILE_DATA";
        private const string FILE_END_MESSAGE = "FILE_END";
        private const string SEPARATOR = "|";

        public MainWindow()
        {
            InitializeComponent();
            MessagesPanel.ItemsSource = messages;
            UserListBox.ItemsSource = users;
        }

        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if (isConnected) return;

            string serverIp = ServerIpTextBox.Text.Trim();
            string portStr = ServerPortTextBox.Text.Trim();
            string username = UsernameTextBox.Text.Trim();

            if (string.IsNullOrEmpty(serverIp) || !int.TryParse(portStr, out int port) || string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Por favor, insira um IP de servidor, porta e nome de usuário válidos.", "Erro de Conexão", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                // Mostrar overlay de status
                StatusText.Text = "Conectando ao servidor...";
                StatusOverlay.Visibility = Visibility.Visible;

                client = new TcpClient();
                await client.ConnectAsync(serverIp, port);
                stream = client.GetStream();
                isConnected = true;

                // Atribuir uma cor para o usuário atual
                Color userColor = avatarColors[random.Next(avatarColors.Length)];
                userColors[username] = userColor;

                // Envia o nome de usuário para o servidor
                byte[] usernameBytes = Encoding.UTF8.GetBytes(username);
                await stream.WriteAsync(usernameBytes, 0, usernameBytes.Length);
                await stream.FlushAsync();

                // Inicia a tarefa para receber mensagens
                receiveTask = Task.Run(() => ReceiveMessages());

                // Atualiza a UI
                Dispatcher.Invoke(() =>
                {
                    ConnectButton.IsEnabled = false;
                    DisconnectButton.IsEnabled = true;
                    MessageTextBox.IsEnabled = true;
                    SendButton.IsEnabled = true;
                    EmoticonButton.IsEnabled = true;
                    ImageButton.IsEnabled = true;
                    FileButton.IsEnabled = true;
                    ServerIpTextBox.IsEnabled = false;
                    ServerPortTextBox.IsEnabled = false;
                    UsernameTextBox.IsEnabled = false;

                    // Adiciona mensagem de sistema
                    messages.Add(new MessageItem
                    {
                        Content = "Conectado ao servidor.",
                        IsSystemMessage = true,
                        Time = DateTime.Now.ToString("HH:mm")
                    });

                    // Esconder overlay de status
                    StatusOverlay.Visibility = Visibility.Collapsed;
                });
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    StatusOverlay.Visibility = Visibility.Collapsed;
                    MessageBox.Show($"Falha ao conectar ao servidor: {ex.Message}", "Erro de Conexão", MessageBoxButton.OK, MessageBoxImage.Error);
                });
                Disconnect(); // Garante que tudo seja limpo
            }
        }

        private void DisconnectButton_Click(object sender, RoutedEventArgs e)
        {
            Disconnect();
        }

        private void Disconnect()
        {
            if (!isConnected) return;

            isConnected = false;
            try
            {
                stream?.Close();
                client?.Close();
            }
            catch { /* Ignora erros ao fechar */ }
            finally
            {
                stream = null;
                client = null;
                receiveTask = null; // A tarefa deve parar por conta própria ao fechar o stream

                // Atualiza a UI usando Dispatcher pois pode ser chamado de outra thread (ReceiveMessages)
                Dispatcher.Invoke(() =>
                {
                    ConnectButton.IsEnabled = true;
                    DisconnectButton.IsEnabled = false;
                    MessageTextBox.IsEnabled = false;
                    SendButton.IsEnabled = false;
                    EmoticonButton.IsEnabled = false;
                    ImageButton.IsEnabled = false;
                    FileButton.IsEnabled = false;
                    ServerIpTextBox.IsEnabled = true;
                    ServerPortTextBox.IsEnabled = true;
                    UsernameTextBox.IsEnabled = true;
                    EmoticonPanel.Visibility = Visibility.Collapsed;

                    // Adiciona mensagem de sistema
                    messages.Add(new MessageItem
                    {
                        Content = "Desconectado do servidor.",
                        IsSystemMessage = true,
                        Time = DateTime.Now.ToString("HH:mm")
                    });

                    users.Clear(); // Limpa a lista de usuários
                });
            }
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            await SendTextMessage();
        }

        private async void MessageTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                await SendTextMessage();
            }
        }

        private async Task SendTextMessage()
        {
            if (!isConnected || string.IsNullOrWhiteSpace(MessageTextBox.Text)) return;

            try
            {
                string message = MessageTextBox.Text;
                string formattedMessage = $"{TEXT_MESSAGE}{SEPARATOR}{UsernameTextBox.Text}{SEPARATOR}{message}";
                byte[] buffer = Encoding.UTF8.GetBytes(formattedMessage);
                await stream.WriteAsync(buffer, 0, buffer.Length);
                await stream.FlushAsync();

                // Limpa a caixa de mensagem
                MessageTextBox.Clear();
                MessageTextBox.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao enviar mensagem: {ex.Message}", "Erro de Comunicação", MessageBoxButton.OK, MessageBoxImage.Error);
                Disconnect();
            }
        }

        private void EmoticonButton_Click(object sender, RoutedEventArgs e)
        {
            // Alterna a visibilidade do painel de emoticons
            EmoticonPanel.Visibility = EmoticonPanel.Visibility == Visibility.Visible
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        private void Emoticon_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Content is string emoticon)
            {
                // Insere o emoticon no campo de texto
                MessageTextBox.Text += emoticon;
                MessageTextBox.CaretIndex = MessageTextBox.Text.Length; // Move o cursor para o final
                MessageTextBox.Focus();

                // Oculta o painel de emoticons
                EmoticonPanel.Visibility = Visibility.Collapsed;
            }
        }

        private async void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isConnected) return;

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.gif;*.bmp",
                Title = "Selecione uma imagem para enviar"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Lê o arquivo de imagem
                    byte[] imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                    string base64Image = Convert.ToBase64String(imageBytes);
                    string fileName = Path.GetFileName(openFileDialog.FileName);

                    // Mostra overlay de progresso
                    ShowTransferOverlay("Enviando imagem...", fileName);

                    // Envia a imagem
                    string formattedMessage = $"{IMAGE_MESSAGE}{SEPARATOR}{UsernameTextBox.Text}{SEPARATOR}{fileName}{SEPARATOR}{base64Image}";
                    byte[] buffer = Encoding.UTF8.GetBytes(formattedMessage);

                    // Atualiza progresso (simulado para imagens pequenas)
                    UpdateTransferProgress(50);
                    await stream.WriteAsync(buffer, 0, buffer.Length);
                    await stream.FlushAsync();
                    UpdateTransferProgress(100);

                    // Oculta overlay após um breve delay
                    await Task.Delay(500);
                    HideTransferOverlay();
                }
                catch (Exception ex)
                {
                    HideTransferOverlay();
                    MessageBox.Show($"Erro ao enviar imagem: {ex.Message}", "Erro de Comunicação", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async void FileButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isConnected) return;

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Todos os arquivos|*.*",
                Title = "Selecione um arquivo para enviar"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    string filePath = openFileDialog.FileName;
                    string fileName = Path.GetFileName(filePath);
                    long fileSize = new FileInfo(filePath).Length;

                    // Gera um ID único para esta transferência
                    string transferId = Guid.NewGuid().ToString();
                    currentTransferId = transferId;
                    isTransferring = true;

                    // Mostra overlay de progresso
                    ShowTransferOverlay("Enviando arquivo...", fileName);

                    // Envia mensagem de início de transferência
                    string initMessage = $"{FILE_INIT_MESSAGE}{SEPARATOR}{UsernameTextBox.Text}{SEPARATOR}{transferId}{SEPARATOR}{fileName}{SEPARATOR}{fileSize}";
                    byte[] initBuffer = Encoding.UTF8.GetBytes(initMessage);
                    await stream.WriteAsync(initBuffer, 0, initBuffer.Length);
                    await stream.FlushAsync();

                    // Envia o arquivo em chunks
                    using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    {
                        byte[] fileBuffer = new byte[8192]; // 8KB chunks
                        int bytesRead;
                        long totalBytesSent = 0;

                        while ((bytesRead = await fileStream.ReadAsync(fileBuffer, 0, fileBuffer.Length)) > 0)
                        {
                            // Converte o chunk para Base64
                            string base64Chunk = Convert.ToBase64String(fileBuffer, 0, bytesRead);

                            // Envia o chunk
                            string dataMessage = $"{FILE_DATA_MESSAGE}{SEPARATOR}{UsernameTextBox.Text}{SEPARATOR}{transferId}{SEPARATOR}{base64Chunk}";
                            byte[] dataBuffer = Encoding.UTF8.GetBytes(dataMessage);
                            await stream.WriteAsync(dataBuffer, 0, dataBuffer.Length);
                            await stream.FlushAsync();

                            // Atualiza o progresso
                            totalBytesSent += bytesRead;
                            int progressPercentage = (int)((double)totalBytesSent / fileSize * 100);
                            UpdateTransferProgress(progressPercentage);

                            // Pequeno delay para não sobrecarregar a rede
                            await Task.Delay(10);
                        }
                    }

                    // Envia mensagem de fim de transferência
                    string endMessage = $"{FILE_END_MESSAGE}{SEPARATOR}{UsernameTextBox.Text}{SEPARATOR}{transferId}";
                    byte[] endBuffer = Encoding.UTF8.GetBytes(endMessage);
                    await stream.WriteAsync(endBuffer, 0, endBuffer.Length);
                    await stream.FlushAsync();

                    // Oculta overlay após um breve delay
                    await Task.Delay(500);
                    HideTransferOverlay();
                    isTransferring = false;
                }
                catch (Exception ex)
                {
                    HideTransferOverlay();
                    isTransferring = false;
                    MessageBox.Show($"Erro ao enviar arquivo: {ex.Message}", "Erro de Comunicação", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ShowTransferOverlay(string status, string fileName)
        {
            Dispatcher.Invoke(() =>
            {
                TransferStatusText.Text = status;
                TransferFileNameText.Text = fileName;
                TransferProgressBar.Value = 0;
                TransferProgressText.Text = "0%";
                TransferOverlay.Visibility = Visibility.Visible;
            });
        }

        private void UpdateTransferProgress(int percentage)
        {
            Dispatcher.Invoke(() =>
            {
                TransferProgressBar.Value = percentage;
                TransferProgressText.Text = $"{percentage}%";
            });
        }

        private void HideTransferOverlay()
        {
            Dispatcher.Invoke(() =>
            {
                TransferOverlay.Visibility = Visibility.Collapsed;
            });
        }

        private async Task ReceiveMessages()
        {
            byte[] buffer = new byte[16384]; // Buffer maior para lidar com imagens e chunks de arquivo
            while (isConnected)
            {
                try
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                    {
                        // Conexão fechada pelo servidor
                        throw new Exception("Conexão perdida com o servidor.");
                    }

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    // Usa Dispatcher para atualizar a UI a partir desta thread secundária
                    Dispatcher.Invoke(() =>
                    {
                        // Verifica se é uma mensagem de lista de usuários
                        if (message.StartsWith("USERLIST|"))
                        {
                            UpdateUserList(message.Substring("USERLIST|".Length));
                        }
                        else
                        {
                            // Processa a mensagem recebida
                            ProcessMessage(message);

                            // Rola para a última mensagem
                            ChatScrollViewer.ScrollToEnd();
                        }
                    });
                }
                catch (Exception ex)
                {
                    // Se não estivermos mais conectados, o erro é esperado (ex: ao desconectar)
                    if (isConnected)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            messages.Add(new MessageItem
                            {
                                Content = $"Erro: {ex.Message}",
                                IsSystemMessage = true,
                                Time = DateTime.Now.ToString("HH:mm")
                            });
                        });
                        Disconnect(); // Tenta desconectar corretamente
                    }
                    break; // Sai do loop de recebimento
                }
            }
        }

        private void ProcessMessage(string message)
        {
            // Verifica se é uma mensagem de sistema (entrada/saída de usuário)
            if (message.Contains(" entrou no chat.") || message.Contains(" saiu do chat."))
            {
                messages.Add(new MessageItem
                {
                    Content = message,
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm")
                });
                return;
            }

            // Tenta processar como mensagem formatada
            string[] parts = message.Split(new string[] { SEPARATOR }, 3, StringSplitOptions.None);
            if (parts.Length >= 3)
            {
                string messageType = parts[0];
                string sender = parts[1];
                string content = parts[2];

                // Atribui uma cor para o usuário se ainda não tiver
                if (!userColors.ContainsKey(sender))
                {
                    userColors[sender] = avatarColors[random.Next(avatarColors.Length)];
                }

                // Processa com base no tipo de mensagem
                switch (messageType)
                {
                    case TEXT_MESSAGE:
                        ProcessTextMessage(sender, content);
                        break;
                    case EMOTICON_MESSAGE:
                        ProcessEmoticonMessage(sender, content);
                        break;
                    case IMAGE_MESSAGE:
                        ProcessImageMessage(sender, content);
                        break;
                    case FILE_INIT_MESSAGE:
                        ProcessFileInitMessage(sender, content);
                        break;
                    case FILE_DATA_MESSAGE:
                        ProcessFileDataMessage(sender, content);
                        break;
                    case FILE_END_MESSAGE:
                        ProcessFileEndMessage(sender, content);
                        break;
                    default:
                        // Formato desconhecido, trata como mensagem de texto simples
                        ProcessLegacyMessage(message);
                        break;
                }
            }
            else
            {
                // Formato antigo: <Remetente> Conteúdo da mensagem
                ProcessLegacyMessage(message);
            }
        }

        private void ProcessTextMessage(string sender, string content)
        {
            bool isOwnMessage = sender == UsernameTextBox.Text;

            messages.Add(new MessageItem
            {
                Sender = sender,
                Content = content,
                IsOwnMessage = isOwnMessage,
                Time = DateTime.Now.ToString("HH:mm"),
                AvatarColor = userColors[sender],
                ContentControl = new TextBlock
                {
                    Text = content,
                    TextWrapping = TextWrapping.Wrap,
                    Foreground = isOwnMessage ? Brushes.White : Brushes.White
                }
            });
        }

        private void ProcessEmoticonMessage(string sender, string content)
        {
            bool isOwnMessage = sender == UsernameTextBox.Text;

            messages.Add(new MessageItem
            {
                Sender = sender,
                Content = content,
                IsOwnMessage = isOwnMessage,
                Time = DateTime.Now.ToString("HH:mm"),
                AvatarColor = userColors[sender],
                ContentControl = new TextBlock
                {
                    Text = content,
                    FontSize = 24,
                    TextWrapping = TextWrapping.Wrap,
                    Foreground = isOwnMessage ? Brushes.White : Brushes.White
                }
            });
        }

        private void ProcessImageMessage(string sender, string content)
        {
            try
            {
                string[] imageParts = content.Split(new string[] { SEPARATOR }, 2, StringSplitOptions.None);
                if (imageParts.Length < 2) return;

                string fileName = imageParts[0];
                string base64Image = imageParts[1];

                // Converte Base64 para imagem
                byte[] imageBytes = Convert.FromBase64String(base64Image);
                BitmapImage bitmapImage = new BitmapImage();
                using (MemoryStream ms = new MemoryStream(imageBytes))
                {
                    bitmapImage.BeginInit();
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.StreamSource = ms;
                    bitmapImage.EndInit();
                    bitmapImage.Freeze(); // Importante para uso em thread diferente
                }

                // Cria controle de imagem
                Image imageControl = new Image
                {
                    Source = bitmapImage,
                    Stretch = Stretch.Uniform,
                    MaxHeight = 200,
                    MaxWidth = 300,
                    HorizontalAlignment = HorizontalAlignment.Left
                };

                bool isOwnMessage = sender == UsernameTextBox.Text;

                messages.Add(new MessageItem
                {
                    Sender = sender,
                    Content = $"[Imagem: {fileName}]", 
                    IsOwnMessage = isOwnMessage,
                    Time = DateTime.Now.ToString("HH:mm"),
                    AvatarColor = userColors[sender],
                    ContentControl = imageControl
                });
            }
            catch (Exception ex)
            {
                messages.Add(new MessageItem
                {
                    Content = $"Erro ao processar imagem: {ex.Message}",
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm")
                });
            }
        }

        private void ProcessFileInitMessage(string sender, string content)
        {
            try
            {
                string[] fileParts = content.Split(new string[] { SEPARATOR }, 3, StringSplitOptions.None);
                if (fileParts.Length < 3) return;

                string transferId = fileParts[0];
                string fileName = fileParts[1];
                long fileSize = long.Parse(fileParts[2]);

                bool isOwnMessage = sender == UsernameTextBox.Text;

                // Cria um novo item de mensagem para o arquivo
                MessageItem fileMessage = new MessageItem
                {
                    Sender = sender,
                    Content = $"[Arquivo: {fileName}]",
                    IsOwnMessage = isOwnMessage,
                    Time = DateTime.Now.ToString("HH:mm"),
                    AvatarColor = userColors[sender],
                    ShowProgress = true,
                    ProgressValue = 0
                };

                // Cria controle para exibir informações do arquivo
                StackPanel filePanel = new StackPanel();
                filePanel.Children.Add(new TextBlock
                {
                    Text = "📄 " + fileName,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = isOwnMessage ? Brushes.White : Brushes.White
                });
                filePanel.Children.Add(new TextBlock
                {
                    Text = $"Tamanho: {FormatFileSize(fileSize)}",
                    Foreground = isOwnMessage ? new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)) : new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)),
                    FontSize = 12,
                    Margin = new Thickness(0, 5, 0, 0)
                });

                // Adiciona botão para baixar (será ativado quando o arquivo estiver completo)
                Button downloadButton = new Button
                {
                    Content = "Recebendo...",
                    IsEnabled = false,
                    Margin = new Thickness(0, 10, 0, 0),
                    Padding = new Thickness(10, 5, 10, 5),
                    Background = new SolidColorBrush(Color.FromRgb(70, 70, 70)),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0),
                    Tag = transferId // Armazena o ID da transferência para referência
                };

                filePanel.Children.Add(downloadButton);
                fileMessage.ContentControl = filePanel;

                // Adiciona à lista de mensagens
                messages.Add(fileMessage);

                // Registra a transferência ativa
                activeTransfers[transferId] = new FileTransferInfo
                {
                    FileName = fileName,
                    FileSize = fileSize,
                    Sender = sender,
                    MessageItem = fileMessage,
                    DownloadButton = downloadButton,
                    Data = new MemoryStream()
                };
            }
            catch (Exception ex)
            {
                messages.Add(new MessageItem
                {
                    Content = $"Erro ao iniciar transferência de arquivo: {ex.Message}",
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm")
                });
            }
        }

        private void ProcessFileDataMessage(string sender, string content)
        {
            try
            {
                string[] dataParts = content.Split(new string[] { SEPARATOR }, 2, StringSplitOptions.None);
                if (dataParts.Length < 2) return;

                string transferId = dataParts[0];
                string base64Chunk = dataParts[1];

                // Verifica se a transferência existe
                if (!activeTransfers.ContainsKey(transferId)) return;

                FileTransferInfo transfer = activeTransfers[transferId];

                // Converte e adiciona o chunk aos dados
                byte[] chunkBytes = Convert.FromBase64String(base64Chunk);
                transfer.Data.Write(chunkBytes, 0, chunkBytes.Length);

                // Atualiza o progresso
                double progress = (double)transfer.Data.Length / transfer.FileSize * 100;
                transfer.MessageItem.ProgressValue = (int)progress;

                // Atualiza o texto do botão
                transfer.DownloadButton.Content = $"Recebendo... {(int)progress}%";
            }
            catch (Exception ex)
            {
                messages.Add(new MessageItem
                {
                    Content = $"Erro ao processar dados de arquivo: {ex.Message}",
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm")
                });
            }
        }

        private void ProcessFileEndMessage(string sender, string content)
        {
            try
            {
                string transferId = content;

                // Verifica se a transferência existe
                if (!activeTransfers.ContainsKey(transferId)) return;

                FileTransferInfo transfer = activeTransfers[transferId];

                // Finaliza a transferência
                transfer.MessageItem.ProgressValue = 100;
                transfer.MessageItem.ShowProgress = false;

                // Atualiza o botão para permitir download
                transfer.DownloadButton.Content = "Salvar arquivo";
                transfer.DownloadButton.IsEnabled = true;
                transfer.DownloadButton.Background = new SolidColorBrush(Color.FromRgb(138, 43, 226));

                // Adiciona evento de clique para salvar o arquivo
                transfer.DownloadButton.Click += (s, e) => SaveReceivedFile(transferId);

                // Reposiciona o stream para o início
                transfer.Data.Position = 0;
            }
            catch (Exception ex)
            {
                messages.Add(new MessageItem
                {
                    Content = $"Erro ao finalizar transferência de arquivo: {ex.Message}",
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm")
                });
            }
        }

        private void SaveReceivedFile(string transferId)
        {
            if (!activeTransfers.ContainsKey(transferId)) return;

            FileTransferInfo transfer = activeTransfers[transferId];

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                FileName = transfer.FileName,
                Filter = "Todos os arquivos|*.*",
                Title = "Salvar arquivo recebido"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    using (FileStream fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                    {
                        transfer.Data.CopyTo(fileStream);
                    }

                    MessageBox.Show($"Arquivo salvo com sucesso em:\n{saveFileDialog.FileName}", "Arquivo Salvo", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao salvar arquivo: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ProcessLegacyMessage(string message)
        {
            // Formato esperado: <Remetente> Conteúdo da mensagem
            if (message.StartsWith("<") && message.Contains(">"))
            {
                int closeBracketIndex = message.IndexOf(">");
                string sender = message.Substring(1, closeBracketIndex - 1);
                string content = message.Substring(closeBracketIndex + 1).Trim();

                // Verifica se é uma mensagem do usuário atual
                bool isOwnMessage = sender == UsernameTextBox.Text;

                // Atribui uma cor para o usuário se ainda não tiver
                if (!userColors.ContainsKey(sender))
                {
                    userColors[sender] = avatarColors[random.Next(avatarColors.Length)];
                }

                messages.Add(new MessageItem
                {
                    Sender = sender,
                    Content = content,
                    IsOwnMessage = isOwnMessage,
                    Time = DateTime.Now.ToString("HH:mm"),
                    AvatarColor = userColors[sender],
                    ContentControl = new TextBlock
                    {
                        Text = content,
                        TextWrapping = TextWrapping.Wrap,
                        Foreground = isOwnMessage ? Brushes.White : Brushes.White
                    }
                });
            }
            else
            {
                // Mensagem em formato desconhecido, exibe como está
                messages.Add(new MessageItem
                {
                    Content = message,
                    IsSystemMessage = true,
                    Time = DateTime.Now.ToString("HH:mm"),
                    ContentControl = new TextBlock
                    {
                        Text = message,
                        TextWrapping = TextWrapping.Wrap,
                        Foreground = Brushes.LightGray
                    }
                });
            }
        }

        private void UpdateUserList(string userListData)
        {
            users.Clear();
            string[] usernames = userListData.Split(',');

            foreach (string username in usernames)
            {
                if (!string.IsNullOrWhiteSpace(username))
                {
                    string name = username.Trim();

                    // Atribui uma cor para o usuário se ainda não tiver
                    if (!userColors.ContainsKey(name))
                    {
                        userColors[name] = avatarColors[random.Next(avatarColors.Length)];
                    }

                    users.Add(new UserItem
                    {
                        Username = name,
                        AvatarColor = userColors[name],
                        IsCurrentUser = name == UsernameTextBox.Text
                    });
                }
            }
        }

        private string FormatFileSize(long bytes)
        {
            string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
            int counter = 0;
            decimal number = bytes;

            while (Math.Round(number / 1024) >= 1)
            {
                number = number / 1024;
                counter++;
            }

            return $"{number:n1} {suffixes[counter]}";
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Disconnect(); // Garante a desconexão ao fechar a janela
        }
    }

    // Classe para representar uma mensagem na UI
    public class MessageItem
    {
        public string Sender { get; set; }
        public string Content { get; set; }
        public string Time { get; set; }
        public bool IsOwnMessage { get; set; }
        public bool IsSystemMessage { get; set; }
        public Color AvatarColor { get; set; }
        public UIElement ContentControl { get; set; }
        public bool ShowProgress { get; set; }
        public int ProgressValue { get; set; }

        // Propriedades para binding no XAML
        public HorizontalAlignment Alignment => IsSystemMessage ? HorizontalAlignment.Center :
                                               IsOwnMessage ? HorizontalAlignment.Right : HorizontalAlignment.Left;

        public Brush Background => IsSystemMessage ? new SolidColorBrush(Color.FromArgb(100, 100, 100, 100)) :
                                  IsOwnMessage ? new SolidColorBrush(Color.FromRgb(138, 43, 226)) :
                                  new SolidColorBrush(Color.FromRgb(30, 30, 30));

        public Brush SenderColor => Brushes.LightGray;

        public Visibility SenderVisibility => IsSystemMessage || IsOwnMessage ? Visibility.Collapsed : Visibility.Visible;

        public Visibility AvatarVisibility => IsSystemMessage || IsOwnMessage ? Visibility.Collapsed : Visibility.Visible;

        public CornerRadius CornerRadius => IsSystemMessage ? new CornerRadius(15) :
                                           IsOwnMessage ? new CornerRadius(15, 0, 15, 15) :
                                           new CornerRadius(0, 15, 15, 15);

        public int ContentColumn => IsOwnMessage || IsSystemMessage ? 0 : 1;

        public Visibility ProgressVisibility => ShowProgress ? Visibility.Visible : Visibility.Collapsed;
    }

    // Classe para representar um usuário na lista
    public class UserItem
    {
        public string Username { get; set; }
        public Color AvatarColor { get; set; }
        public bool IsCurrentUser { get; set; }
    }

    // Classe para armazenar informações de transferência de arquivo
    public class FileTransferInfo
    {
        public string FileName { get; set; }
        public long FileSize { get; set; }
        public string Sender { get; set; }
        public MessageItem MessageItem { get; set; }
        public Button DownloadButton { get; set; }
        public MemoryStream Data { get; set; }
    }
}
