﻿// Server.cs
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class ChatServer
{
    private static TcpListener tcpListener;
    private static List<ClientInfo> clients = new List<ClientInfo>();
    private static readonly object lockObj = new object();

    public static void Main(string[] args)
    {
        int port = 8888; // Porta padrão
        if (args.Length > 0)
        {
            int.TryParse(args[0], out port);
        }

        try
        {
            tcpListener = new TcpListener(IPAddress.Any, port);
            tcpListener.Start();
            Console.WriteLine($"Servidor iniciado na porta {port}. Aguardando conexões...");

            while (true)
            {
                TcpClient client = tcpListener.AcceptTcpClient();
                // Cria uma nova thread ou usa Task para lidar com o cliente
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClient));
                clientThread.Start(client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro no servidor: {ex.Message}");
        }
        finally
        {
            tcpListener?.Stop();
        }
    }

    private static void HandleClient(object clientObj)
    {
        TcpClient tcpClient = (TcpClient)clientObj;
        NetworkStream clientStream = tcpClient.GetStream();
        ClientInfo clientInfo = new ClientInfo { TcpClient = tcpClient, Stream = clientStream };
        string clientName = "Desconhecido";

        try
        {
            byte[] message = new byte[4096];
            int bytesRead;

            // Primeira mensagem é o nome do usuário
            bytesRead = clientStream.Read(message, 0, 4096);
            if (bytesRead == 0)
            {
                // Cliente desconectou antes de enviar o nome
                tcpClient.Close();
                return;
            }
            clientName = Encoding.UTF8.GetString(message, 0, bytesRead);
            clientInfo.Name = clientName;

            lock (lockObj)
            {
                clients.Add(clientInfo);
            }

            Console.WriteLine($"{clientName} conectou-se.");
            BroadcastMessage($"<{clientName}> entrou no chat.", clientInfo, true); // Notifica a todos
            SendUserList(); // Envia a lista atualizada de usuários

            // Loop para receber mensagens do cliente
            while ((bytesRead = clientStream.Read(message, 0, 4096)) > 0)
            {
                string msg = Encoding.UTF8.GetString(message, 0, bytesRead);
                Console.WriteLine($"Recebido de {clientName}: {msg}");
                BroadcastMessage($"<{clientName}> {msg}", clientInfo, false);
            }
        }
        catch (Exception ex)
        {
            // Considera erro como desconexão
            // Console.WriteLine($"Erro ao lidar com cliente {clientName}: {ex.Message}");
        }
        finally
        {
            Console.WriteLine($"{clientName} desconectou-se.");
            lock (lockObj)
            {
                clients.Remove(clientInfo);
            }
            BroadcastMessage($"<{clientName}> saiu do chat.", null, true); // Notifica a todos
            SendUserList(); // Envia a lista atualizada
            tcpClient.Close();
        }
    }

    private static void BroadcastMessage(string message, ClientInfo sender, bool isNotification)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(message);
        List<ClientInfo> clientsCopy;
        lock (lockObj)
        {
            clientsCopy = new List<ClientInfo>(clients);
        }

        foreach (ClientInfo client in clientsCopy)
        {
            // Não envia a mensagem de volta para o remetente, a menos que seja notificação geral
            if (!isNotification && client == sender) continue;

            try
            {
                client.Stream.Write(buffer, 0, buffer.Length);
                client.Stream.Flush();
            }
            catch (Exception ex)
            {
                // Pode remover o cliente se houver erro ao enviar
                Console.WriteLine($"Erro ao enviar para {client.Name}: {ex.Message}. Removendo cliente.");
                // Remover com segurança em um loop separado ou marcar para remoção
            }
        }
    }

    private static void SendUserList()
    {
        List<string> userNames = new List<string>();
        List<ClientInfo> clientsCopy;
        lock (lockObj)
        {
            clientsCopy = new List<ClientInfo>(clients);
            foreach (var c in clientsCopy)
            {
                userNames.Add(c.Name);
            }
        }

        string userListMessage = "USERLIST|" + string.Join(",", userNames);
        byte[] buffer = Encoding.UTF8.GetBytes(userListMessage);

        foreach (ClientInfo client in clientsCopy)
        {
            try
            {
                client.Stream.Write(buffer, 0, buffer.Length);
                client.Stream.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao enviar lista de usuários para {client.Name}: {ex.Message}.");
            }
        }
    }
}

public class ClientInfo
{
    public TcpClient TcpClient { get; set; }
    public NetworkStream Stream { get; set; }
    public string Name { get; set; }
}

